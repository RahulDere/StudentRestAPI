
CREATE DATABASE IF NOT EXISTS `SchoolBlockOne` ;

USE `SchoolBlockOne`;
CREATE TABLE IF NOT EXISTS `STUDENTCLASS` (
  `StudentClassID` int4(50) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `CellPhone` varchar(50) NULL,
  `StudentCredit` varchar(100) NOT NULL,
  `Nameclass` varchar(50),
  `National` varchar(50) NOT NULL,
  `Semester` int4(50) NULL,
  PRIMARY KEY (`StudentClassID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `USERS` (
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- $2a$10$N0eqNiuikWCy9ETQ1rdau.XEELcyEO7kukkfoiNISk/9F7gw6eB0W
-- $2a$10$QifQnP.XqXDW0Lc4hSqEg.GhTqZHoN2Y52/hoWr4I5ePxK7D2Pi8q
--INSERT INTO `users` (`username`, `password`, `full_name`, `role`, `country`, `enabled`) VALUES
--	('RahulDere', '******', 'Rahul Dere', 'ROLE_USER', 'USA', 1),
--	('BlockOne', '******',, 'School Block One', 'ROLE_SCHOOL_ADMIN', 'USA', 1); 
	
INSERT INTO `users` (`loginname`, `password`, `full_name`, `role`, `country`, `enabled`) VALUES
	('RahulDere', '$2a$10$al8KcTIYr4/nsTg8wHnZ2OMjvefLz0keNU1NcwcEpHP6bH8drL/SO', 'Rahul Dere', 'ROLE_USER', 'USA', 1),
	('BlockOne', '$2a$10$mZGvaKr/nmZDDYut6TqwoeThap9q/Le.yey3jIUWOtUjN8MNxsqWq', 'School Block One', 'ROLE_SCHOOL_ADMIN', 'USA', 1); 
	
select * from users;
select * from StudentClass;