package com.blockone.schoolwebapi.api;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.blockone.schoolwebapi.entity.StudentClass;
import com.blockone.schoolwebapi.service.IStudentService;

@RestController
public class StudentController {
	
	@Autowired
	private IStudentService studentService;
	
	//API to add new students or modify them
	//HTTP POST /student
	@PostMapping("/student")
	public synchronized StudentClass addStudent(@RequestBody StudentClass student) {

		boolean flag = studentService.addStudents(student);
        if (flag == false) {
        	return null;
        }
        return student;
	}
	
	//API to create a new semester
	//HTTP POST /semesters/{id}
	@PostMapping("/semester")
	public StudentClass addSemester(@RequestBody StudentClass student) {
        boolean flag = studentService.updateStudentSemester(student);
        if (flag == false) {
        	return null;
        }
     
        return student;
	}
	
	//API to get the list of classes for a particular student for a semester, 
	//HTTP GET /classes?studentId=1&semester=2	
	@GetMapping("/classes")
	public Set<String> getAllClassesOfStudent(@RequestParam(name = "studentId") int studentId, @RequestParam int semester) {
		List<StudentClass> setOfClasses = studentService.getAllClassesbyStudentAndSemester(studentId, semester);
		Set<String> classNames = setOfClasses.stream().map(std -> std.nameclass).collect(Collectors.toSet());
		return classNames;
	}
	
	//API to get the list of students enrolled in a class for a particular semester.
	//HTTP GET /students?classname='1A'&semester=2
	@GetMapping("/students")
	public List<StudentClass> getAllStudentsbyClassAndSemester(@RequestParam(name = "classname") String className, @RequestParam int semester) {
		List<StudentClass> list = studentService.getAllStudentbyClassAndSemester(className, semester);
		return list;
	}
	
	//API to enroll a student into a class for a particular semester
	//HTTP PUT /student/{id}
	@PutMapping("/student/{id}")
	public StudentClass updateStudentIntoClass(@RequestBody StudentClass student) {
		studentService.updateStudents(student);
		return student;
	}

    //API to drop a student from a class.
	//HTTP DELETE /class/{id}/students/{id}
    @DeleteMapping("/Class/{id}/student/{id}") 
	public void deleteStudentfromClass(@PathVariable("id") int studentId, String className) {
    	studentService.deleteStudent(studentId, className);
	}
	
	
}
