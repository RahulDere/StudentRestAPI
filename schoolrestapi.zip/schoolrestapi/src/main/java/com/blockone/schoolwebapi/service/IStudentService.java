package com.blockone.schoolwebapi.service;

import java.util.List;
import org.springframework.security.access.annotation.Secured;

import com.blockone.schoolwebapi.entity.StudentClass;

public interface IStudentService {

	 @Secured ({"ROLE_SCHOOL_ADMIN", "ROLE_USER"})
	 List<StudentClass> getAllStudentbyClassAndSemester(String className, int semester);
     @Secured ({"ROLE_SCHOOL_ADMIN", "ROLE_USER"})
     StudentClass getStudentById(int studentID);
	 @Secured ({"ROLE_SCHOOL_ADMIN"})
	 boolean addStudents(StudentClass student);
	 @Secured ({"ROLE_SCHOOL_ADMIN"})
	 void updateStudents(StudentClass student);
	 //No Admin can delete the record.
	 @Secured ({"ROLE_USER"})
	 void deleteStudent(int studentID, String className);
	 @Secured ({"ROLE_SCHOOL_ADMIN"})
	 boolean updateStudentSemester(StudentClass student);
	 @Secured ({"ROLE_SCHOOL_ADMIN", "ROLE_USER"})
	 List<StudentClass> getAllClassesbyStudentAndSemester(int studentID, int semester);
	 
	 
	 
}
