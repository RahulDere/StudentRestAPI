package com.blockone.schoolwebapi.DAO;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.blockone.schoolwebapi.entity.StudentClass;

@Transactional
@Repository
public class StudentClassDAO implements IStudentClassDAO {

	//container injects the EntityManager and manages life cycle of transaction.
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	public List<StudentClass> getAllStudentbyClassAndSemester(String className, int semester) {

	    String hql = "FROM StudentClass studclass WHERE studclass.nameclass=:classname and studclass.Semester =:semester";
	    return (List<StudentClass>) entityManager
	    		.createQuery(hql)
	    		.setParameter("classname", className)
	    		.setParameter("semester", semester)
	    		.getResultList();

	}

	@Override
	public StudentClass getStudentById(int studentID) {
		return entityManager.find(StudentClass.class, studentID);
	}

	@Override
	public void addStudents(StudentClass student) {
		entityManager.persist(student);		
	}

	@Override
	public void updateStudents(StudentClass student) {
		
		StudentClass stud = getStudentById(student.getStudentClassID());
		stud.setCellPhone(student.CellPhone);
		stud.setNational(student.getNational());
		stud.setNameclass(student.getNameclass());
		stud.setTotalCredit(student.getTotalCredit());
		entityManager.flush();
		
	}
	
	@Override
	public boolean updateStudentSemester(StudentClass student) {
		
		StudentClass stud = getStudentById(student.getStudentClassID());	
		stud.setSemester(student.getSemester());
		entityManager.flush();
		return true;
		
	}
	

	@Override
	public void deleteStudent(int studentID, String className) {
		  String hql = "FROM StudentClass studclass WHERE studclass.nameclass =:classname and studclass.StudentClassID =:studentid";
		  int delStudentID = entityManager
		    		.createQuery(hql)
		    		.setParameter("classname", className)
		    		.setParameter("studentid", studentID)
		    		.getFirstResult();
		entityManager.remove(delStudentID);		
	}

	@Override
	public boolean studentEnrollExists(String FirstName, String LastName, long CellPhone) {
		String hql = "FROM StudentClass studclass WHERE studclass.FirstName =:firstname and studclass.LastName =:lastname  and studclass.CellPhone =:cellphone";
		int count = entityManager.createQuery(hql)
					.setParameter("firstname", FirstName)
		            .setParameter("lastname", LastName)
		            .setParameter("cellphone", CellPhone)
		            .getResultList().size();
		return count > 0 ? true : false;
	}

	@Override
	public List<StudentClass> getAllClassesbyStudentAndSemester(int studentID, int semester) {
		
	    String hql = "FROM StudentClass studclass WHERE studclass.StudentClassID=:studentid and studclass.Semester =:semester";
	    return (List<StudentClass>) entityManager
	    		.createQuery(hql)
	    		.setParameter("studentid", studentID)
	    		.setParameter("semester", semester)
	    		.getResultList();

	}


}
