package com.blockone.schoolwebapi.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentclass")
public class StudentClass {
	
	//Table data columns
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="studentclassid")
	private int StudentClassID;
	
	@Column(name="firstname")
	public String FirstName;
	@Column(name="lastname")
	public String LastName;
	
	@Column(name="cellphone")
	public long CellPhone;
	
	@Column(name="studentcredit")
	public int TotalCredit;
	
	@Column(name="class")
	public String nameclass;
	
	@Column(name="national")
	public String national;
	
	@Column(name="semester")
	public int Semester;
	
	//All persistent classes must have a default constructor
	public StudentClass () {
		
	}

	public int getStudentClassID() {
		return StudentClassID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public long getCellPhone() {
		return CellPhone;
	}

	public void setCellPhone(long cellPhone) {
		CellPhone = cellPhone;
	}

	public int getTotalCredit() {
		return TotalCredit;
	}

	public void setTotalCredit(int totalCredit) {
		TotalCredit = totalCredit;
	}

	public String getNameclass() {
		return nameclass;
	}

	public void setNameclass(String classname) {
		this.nameclass = classname;
	}

	public String getNational() {
		return national;
	}

	public void setNational(String national) {
		this.national = national;
	}

	public int getSemester() {
		return Semester;
	}

	public void setSemester(int semester) {
		Semester = semester;
	}

	
}
