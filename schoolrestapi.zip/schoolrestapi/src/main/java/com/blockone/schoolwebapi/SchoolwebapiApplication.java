package com.blockone.schoolwebapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolwebapiApplication {

	public static void main(String[] args) {
		
		/*BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		System.out.println(encoder.encode("****@2"));
		System.out.println(encoder.encode("rahul****@1"));*/
		
		SpringApplication.run(SchoolwebapiApplication.class, args);
	}

}
