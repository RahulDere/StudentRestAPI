package com.blockone.schoolwebapi.DAO;

import com.blockone.schoolwebapi.entity.UserInfo;

public interface IUserInfoDAO {
	//Method to get userDetails from DB.
	UserInfo getActiveUser(String loginName);
}