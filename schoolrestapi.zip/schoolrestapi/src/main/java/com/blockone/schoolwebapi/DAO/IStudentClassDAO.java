package com.blockone.schoolwebapi.DAO;

import java.util.List;
import com.blockone.schoolwebapi.entity.StudentClass;

public interface IStudentClassDAO {
	 //methods to interact with Mysql Database.
	 List<StudentClass> getAllStudentbyClassAndSemester(String className, int semester);
	 StudentClass getStudentById(int studentID);
	 void addStudents(StudentClass student);
	 void updateStudents(StudentClass student);
	 void deleteStudent(int studentID, String className);
	 boolean studentEnrollExists(String FirstName, String LastName, long CellPhone);
	 boolean updateStudentSemester(StudentClass student);
	 List<StudentClass> getAllClassesbyStudentAndSemester(int studentID, int semester);
}
