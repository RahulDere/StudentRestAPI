package com.blockone.schoolwebapi.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blockone.schoolwebapi.DAO.IStudentClassDAO;
import com.blockone.schoolwebapi.entity.StudentClass;
@Service
public class StudentService implements IStudentService {
	
	@Autowired
	private IStudentClassDAO istudentDAO;
	
	@Override
	public List<StudentClass> getAllStudentbyClassAndSemester(String className, int semester) {
		return istudentDAO.getAllStudentbyClassAndSemester(className, semester);
	
	}

	@Override
	public StudentClass getStudentById(int studentID) {
		
		StudentClass studObj = istudentDAO.getStudentById(studentID);
		return studObj;
	}

	@Override
	public boolean addStudents(StudentClass student) {
       if (istudentDAO.studentEnrollExists(student.getFirstName(),student.getLastName(), student.getCellPhone())) {
    	   return false;
       } else {
    	   istudentDAO.addStudents(student);
    	   return true;
       }
	
	}

	@Override
	public void updateStudents(StudentClass student) {
		istudentDAO.updateStudents(student);
		
	}

	@Override
	public void deleteStudent(int studentID, String className) {
		istudentDAO.deleteStudent(studentID,className);
		
	}

	@Override
	public boolean updateStudentSemester(StudentClass student) {
		return istudentDAO.updateStudentSemester(student);		
	}

	@Override
	public List<StudentClass> getAllClassesbyStudentAndSemester(int studentID, int semester) {
		
		return istudentDAO.getAllClassesbyStudentAndSemester(studentID, semester);
	}


}
