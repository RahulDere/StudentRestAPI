package com.blockone.schoolwebapi.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class AccessDeniedException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = -8943262369074464268L;

	public AccessDeniedException(String exception) {
        super(exception);
    }
}
