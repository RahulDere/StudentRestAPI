package com.blockone.schoolwebapi.exception;

import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class ExceptionConfig {
	//Add different exception for user friendly messages by extending class with ResponseEntityExceptionHandler
}

