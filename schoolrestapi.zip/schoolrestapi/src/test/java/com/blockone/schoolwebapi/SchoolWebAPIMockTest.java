package com.blockone.schoolwebapi;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.blockone.schoolwebapi.entity.StudentClass;
import com.blockone.schoolwebapi.service.StudentService;

@RunWith(MockitoJUnitRunner.class)
public class SchoolWebAPIMockTest {

	@Mock
	StudentService studentService;
	
	@Test
	public void testgetAllStudentbyClassAndSemester() {
		StudentClass students = new StudentClass();
            
		when(studentService.getAllStudentbyClassAndSemester("1A", 2)).thenReturn(Arrays.asList(students));
		assertEquals(students.FirstName="Rahul", studentService.getAllStudentbyClassAndSemester("1A", 2));
	}
	
	@Test
	public void testAddStudent() {
		StudentClass Student1 = new StudentClass();
        Student1.setFirstName("Rahul");
        Student1.setFirstName("Dere");
        Student1.national = "USA";
        Student1.TotalCredit = 4;
        Student1.nameclass = "1A";
		Student1.setSemester(1);  
        
		when(studentService.addStudents(Student1)).thenReturn(true);
		assertEquals("Strudent added", true, studentService.addStudents(Student1));
		
	}
}
