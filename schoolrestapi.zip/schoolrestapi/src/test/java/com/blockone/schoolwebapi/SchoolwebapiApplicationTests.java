package com.blockone.schoolwebapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolwebapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
